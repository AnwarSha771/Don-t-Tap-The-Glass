
const canvas = document.getElementById('glassCanvas');
const ctx = canvas.getContext('2d');
const tapSound = document.getElementById('tapSound');
const crackSound = document.getElementById('crackSound');
const screamSound = document.getElementById('screamSound');
const jumpscare = document.getElementById('jumpscare');
const eye = document.getElementById('eye');
const resetBtn = document.getElementById('resetBtn');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let ripples = [];
let cracks = [];
let tapCount = Number(localStorage.getItem('tapCount')) || 0;

function createRipple(x, y) {
  ripples.push({ x, y, radius: 0 });
}

function crackGlass(x, y) {
  cracks.push({ x, y, opacity: 1 });
}

function drawRipples() {
  ripples.forEach((ripple, index) => {
    ripple.radius += 2;
    ctx.beginPath();
    ctx.arc(ripple.x, ripple.y, ripple.radius, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(255, 255, 255, ${1 - ripple.radius / 200})`;
    ctx.stroke();
    if (ripple.radius > 200) ripples.splice(index, 1);
  });
}

function drawCracks() {
  cracks.forEach((crack, index) => {
    ctx.beginPath();
    ctx.arc(crack.x, crack.y, 40, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(255, 0, 0, ${crack.opacity})`;
    ctx.setLineDash([5, 15]);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    crack.opacity -= 0.01;
    if (crack.opacity <= 0) cracks.splice(index, 1);
  });
}

function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawRipples();
  drawCracks();
  requestAnimationFrame(animate);
}

canvas.addEventListener('pointerdown', (e) => {
  createRipple(e.clientX, e.clientY);
  tapSound.play();
  tapCount++;
  localStorage.setItem('tapCount', tapCount);

  if (tapCount === 3) {
    crackGlass(e.clientX, e.clientY);
    crackSound.play();
  }

  if (tapCount === 5) {
    jumpscare.style.display = 'block';
    screamSound.play();
    setTimeout(() => {
      jumpscare.style.display = 'none';
    }, 2000);
  }
});

window.addEventListener('resize', () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});

document.addEventListener('mousemove', (e) => {
  eye.style.transform = `translate(${e.clientX - window.innerWidth / 2}px, ${e.clientY - window.innerHeight / 2}px)`;
});

resetBtn.addEventListener('click', () => {
  tapCount = 0;
  localStorage.setItem('tapCount', 0);
  cracks = [];
});

animate();
